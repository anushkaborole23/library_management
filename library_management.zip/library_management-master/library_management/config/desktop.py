from frappe import _

def get_data():
	return {
		"Library Management": {
			"color": "#589494",
			"icon": "icon-book",
			"type": "module",
			"label": _("Library Management")
		}
	}
